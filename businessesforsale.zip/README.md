pip install -r requirements.txt

In the file "settings.py" specify the sections from which you need to collect information and database update options.

Run the script with the command: 'python run.py'


